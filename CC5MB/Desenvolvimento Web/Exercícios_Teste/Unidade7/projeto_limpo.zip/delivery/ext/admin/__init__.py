from flask_admin import Admin

from delivery.ext.admin.views import UserAdmin
from delivery.models.user import User
from delivery.ext.db import db

admin = Admin(
    name="UVVFoods",
    template_mode="bootstrap4"
    )

def init_app(app):
    admin.init_app(app)

admin.add_view(
    UserAdmin(User, db.session)
    )

