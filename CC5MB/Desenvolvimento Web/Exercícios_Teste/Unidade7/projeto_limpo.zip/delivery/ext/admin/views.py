from flask_admin.contrib.sqla import ModelView
from delivery.models.user import User
from delivery.ext.db import db

class UserAdmin(ModelView):
    column_list = [
        "id",
        "email",
        "active",
    ]
 
    column_searchable_list = [
        "email",
    ]

    column_filters = [
        "active",
    ]

    can_export = True