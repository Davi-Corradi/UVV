﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UVVkedin
{
    internal class ListaDeAmigos
    {

        public string Apelido { get; set; } = "";
        public string Telefone { get; set; } = "";
        public string Email { get; set; } = "";

        public List<ListaDeAmigos> ListarTodos() 
        {
            return BD.RetornarBD();
        }
    }
}
